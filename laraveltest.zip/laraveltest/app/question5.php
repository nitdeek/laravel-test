<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class question5 extends Model
{
    protected $table="question5";
}
