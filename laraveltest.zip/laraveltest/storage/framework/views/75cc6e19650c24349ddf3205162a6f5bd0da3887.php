<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Registration form</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" ></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="public/css/style1.css">
</head>
<body>
	<div class="container">
		
			<form action="submit" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<h3 class="text-center form">Registration Form</h3>
		
				<div class="row">
					<div class="col-md-2"><h4>Name:</h4></div>
					<div class="col-md-10"><input id="name" type="text" name="Name" class="form-control"  required="required"></div>
				</div>
				<div class="row">
					<div class="col-md-2 first"><h4>Email:</h4></div>
					<div class="col-md-10 first"><input type="email" id="email" name="email" class="form-control" required="required" ></div>
				</div>
				<div class="row">
					<div class="col-md-3 first"><h4>Password:</h4></div>
					<div class="col-md-9 first"><input type="Password" name="password" class="form-control" required="required"></div>
				</div>
				<div class="row">
					<div class="col-md-2 first"><h4>Phone:</h4></div>
					<div class="col-md-10 first"><input type="number" name="number" class="form-control" required="required"></div>
				</div>
				<div class="row">
					<div class="col-md-3 first"><h4 >Address:</h4></div>
					<div class="col-md-9 first"><textarea name="address" id="address" class="form-control" required="required"></textarea></div>
				</div>
				<div class="row">
					<div class="col-md-3 first"><h4>Id Proof:</h4></div>
					<div class="col-md-9 first"><input type="file" name="file" class="form-control btn btn-important" required="required"></div>
				</div>
				<div class="row">
					<div class="col-md-2 first"><h4>Birth:</h4></div>
					<div class="col-md-10 first"><input type="date" name="birth" class="form-control" required="required"></div>
				</div>
				<div class="row">
					<div class="col-md-6 second"><input type="submit" name="submit" value="submit" class="btn btn-primary float-right"></div>
					<div class="col-md-6 second1"><a href="logon" class="btn btn-info">or Log In</a></div>
				</div>
			</form>
	</div>
<!--<script src="bootstrap-Validate.js"></script>
<script>
	
		bootstrapValidate('#email','required:please fill out this field')
	</script>-->
</body>
</html>

<?php /**PATH D:\xampp\htdocs\laravel\resources\views/registration.blade.php ENDPATH**/ ?>