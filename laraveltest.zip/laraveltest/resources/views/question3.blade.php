<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<style type="text/css">
	#gayab{
		display: none;
	}
	*{
	margin: 0px;
	padding: 0px;
}
body{
	background-image: url(public/img/laptop8.jpg);
	background-size: cover;
	background-attachment: fixed;
}
.container{
	margin:auto;
	margin-top:5%;
	width: 34%;
	box-shadow: -1px 1px 30px 16px black;
	background: rgba(0,0,0,0.6);
}
h3{
	color: white;
	padding:20px;
	text-align: center;
	font-size: 25px;
}
#sub{
	width: 90%;
	margin-left: 5%;
}
#q1{
	height: 20px;
	width: 57%;
	font-size: 15px;
	float: right;
}
#sub{
	margin-top: 3%;
	margin-bottom: 2%;
	width: 30%;
	font-size: 20px;
}
</style>
<body>
	<div class="container">
		
	
<form method="post" action="nexta">
	@csrf
	<table style="width: 100%">
		<tr>
			<td>
			 <label style="font-size: 25px;color: white;" for="q1">Q3:- what is the favorite food?</label><br>
			</td>
			</tr>
			<tr>
			<td style="color: white;font-size: 22px;" >
				pizza:<input id="q1" type="radio" name="color" value="pizza"><br>
				pasta:<input id="q1" type="radio" name="color" value="pasta"><br>
				burger:<input id="q1" type="radio" name="color" value="burger"><br>
				noodles:<input id="q1" type="radio" name="color" value="noodles">
				<input id="gayab" type="text" name="id" value="{{$order->id}}">
				<input id="gayab" type="text" name="qid" value="what is the favorite food?">
				<input id="gayab" type="text" name="qids" value="3">
			</td>
		</tr>
		<tr>
			<td>
				<input id="sub" type="submit" name="submit" value="next">
			</td>
		</tr>
	</table>
</form>
</div>
</body>
</html>