<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="public/css/lists.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-md-5 one">
			<img class="img" height="300px" src="public/images/laptop15.jpg">
		</div>
		<div class="col-md-1"></div>
		<div class="col-md-6 two">
			<div class="row">
				<div class="col-md-12">
					<h2 class="text-center">ASUS AF67</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<h3>Features</h3>
					<li>Nano Edge Display</li>
					<li>Light Weight</li>
					<li>Hd Display</li>
					<li>Super Battery</li>
					<li>4GB RAM</li>
					<li>i3 Proccessor</li>
				</div>
				<div class="col-md-6">
					<h2 class="text-center">Price List</h2>
					<li>$400</li>
					<li>$500</li>
					<li>$600</li>
					<li>$700</li>
				</div>
			</div> 
			<div class="row">
				<div class="col-md-12 text-center">
				<a  href="#" class="btn btn-primary">Buy Now</a>
			</div>
			</div> 
		</div>
	</div>
</div>


</body>
</html><?php /**PATH D:\xampp\htdocs\laravel\resources\views/list2.blade.php ENDPATH**/ ?>