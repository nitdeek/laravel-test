<style type="text/css">
	body{
		background-color:black;
	}
	table{
		border-collapse: collapse;
		margin:auto;
		margin-top: 5%;
		border:3px solid orange;
	}
	tr,td{
		padding: 25px;
		color: white;
		font-size: 20px;
	}
	input{
		border:3px solid orange;
		width: 100%;
		height: 30px;
	}
</style>
<form method="post" action="add">
	<?php echo csrf_field(); ?>
<table border="1">
	<caption style="font-size: 20px;color: white;margin-bottom: 2%;">Add your new product</caption>
	<tr>
		<td>
			product name
		</td>
		<td>
			<input type="text" name="item_name">
		</td>
	</tr>
	<tr>
		<td>
			price
		</td>
		<td>
			<input type="text" name="price">
		</td>
	</tr>
	<tr>
		<td>
			description
		</td>
		<td>
			<input type="text" name="description">
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<input type="submit" name="submit" value="submit">
		</td>
	</tr>
</table>
</form><?php /**PATH D:\xampp\htdocs\laravel\resources\views/add.blade.php ENDPATH**/ ?>