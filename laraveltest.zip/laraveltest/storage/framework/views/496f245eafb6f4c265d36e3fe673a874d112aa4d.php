<style type="text/css">
	*{
		margin: 0;
		background-color: black;
	}
	table{
		border: 1px solid orange;
		color:orange;
		margin:auto;
		margin-top: 5%;
	}
	tr,th,td,caption{
		padding: 20px;
		font-size: 20px;
	}
	#del,#up{
		text-decoration: none;
	}

	#new{
			text-decoration: none;
			border:1px solid orange;
			padding: 7px;
			color: white;
			float: right;
			margin-right: 5%;
	}
</style>
<br>
	<table border='1' style='border-collapse: collapse;'>
		<caption>Products</caption>
		<tr>
			<th>
				item name
			</th>
			<th>
				price
			</th>
			<th>
				description
			</th>
			<th>
				delete
			</th>
			<th>
				update
			</th>
		</tr>
			<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td>
			<?php echo e($selects->item_name); ?>

		</td>
			<td>
			<?php echo e($selects->price); ?>

		</td>
			<td>
			<?php echo e($selects->description); ?>

		</td>
		<td>
			<a id="del" href="delete?id=<?php echo e($selects->id); ?>" style="color: red;">delete</a>		
		</td>
		<td>
		<a id="up" href="update?id=<?php echo e($selects->id); ?>"  style="color: green;">update</a>
		</td>
		</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>	
<a id="new" href="new">create new order</a>






<?php /**PATH D:\xampp\htdocs\laravel\resources\views/submittedorder.blade.php ENDPATH**/ ?>