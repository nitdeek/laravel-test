<?php
session_start();

$sname='localhost';
$user='root';
$password='Nitish@123';
$dbname='project2';

$email=$_SESSION['emm'];
$Password=$_SESSION['pss'];

$myconn= new mysqli($sname,$user,$password,$dbname);
$sql="select * from laptop where email='$email' and password='$Password'";

$result=$myconn->query($sql);
$row=mysqli_num_rows($result);

if($row>0)
{ $res=$result->fetch_assoc();
	$email=$res['email'];
	$Password=$res['password'];
	Redirect()->to('login3')->send();
	
}else{
	echo"<html>
	<head></head>
	<body>

	<h1 align='center'>Not valid Email id or Password</h1>
	<h2 align='center' ><a href='logon'>Try again</a></h2>
	</body>
	</html>";
}
?><?php /**PATH D:\xampp\htdocs\laravel\resources\views/login1.blade.php ENDPATH**/ ?>