<?php
$name=$_POST['Name'];
$email=$_POST['email'];
$number=$_POST['number'];
$address=$_POST['address'];
$Password=$_POST['password'];
$birth=$_POST['birth'];
$tmpname=$_FILES['file']['tmp_name'];
$file=$_FILES['file'];
$image=$file['name'];
$location='public/upload/'.$image;

if(move_uploaded_file($tmpname,$location))
{echo"uploaded";
}else{
	echo" file Not uploaded";
}

$sname='localhost';
$user='root';
$password='Nitish@123';
$dbname='project2';

$myconn= new mysqli($sname,$user,$password,$dbname);
$sql="insert into laptop(name,email,number,address,file,birth,password)values('$name','$email','$number','$address','$location','$birth','$Password')";
if($myconn->query($sql))
{
	 Redirect()->to('login3')->send(); 
}else{
	echo"not saved";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php echo csrf_field(); ?>

</body>
</html><?php /**PATH D:\xampp\htdocs\laravel\resources\views/submit.blade.php ENDPATH**/ ?>