<!DOCTYPE html>
<html>
<head>
	<title>select</title>
	<style type="text/css">
		body{
		margin:0;
		background-color: #757575;	
		}
		.first{
			border:1px solid  #00CCCC;
			width:60%;
			margin:auto;
			height: 480px;
			background-color: white;
			margin-top: 7%;
		}
		.one{
			width:40%;
			margin-left: 8%;
			margin-right: 2%;
			display: inline-block;
			height: 70px;
		}
		.two{
			
			width:40%;
			display: inline-block;
			height: 70px;
		}
		a{
			text-decoration: none;
			margin-left: 24%;
			font-size: 40px;
			color: #00CCCC;
		}
		h1{
			text-align: center;
			padding: 40px;
			font-size: 50px;
			color: red;

		}
	</style>
</head>
<body>
	<div class="first">
		<h1>Welcome to our Quiz zone</h1>
	<div class="one">
	<a href="fillform">Solve Quiz</a>	
	</div>
	<div class="two">
	<a href="createform">Create Quiz</a>	
	</div>
</div>
	
	

</body>
</html>