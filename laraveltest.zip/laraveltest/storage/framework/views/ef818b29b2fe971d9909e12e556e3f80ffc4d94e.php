<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>log in</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" ></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="public/css/style2.css">
</head>
<?php
if(isset($_COOKIE['ema']) && isset($_COOKIE['pas']))
{
	redirect()->to('login3')->send();
}
?>
<body>
	<div class="container">
		
			<form  action="login2" method="post">
				<?php echo csrf_field(); ?>
				<h3 class="text-center form">Log In</h3>
		
				<div class="row">
					<div class="col-md-3"><h4>Username:</h4></div>
					<div class="col-md-9 "><input type="text" name="email" class="form-control" required="required"></div>
				</div>
				<div class="row">
					<div class="col-md-3 first"><h4>Password:</h4></div>
					<div class="col-md-9 first"><input type="Password" name="password" class="form-control" required="required"></div>
				</div>
				<div class="row">
					<div class="col-md-4 second1"><input type="checkbox" name="remember" class="checkbox">Remember Me</div>
					<div class="col-md-8 second"><input type="submit" name="submit" value="Log In" class="btn btn-primary"></div>
				</div>
			</form>
	</div>			

</body>
</html>


<?php /**PATH D:\xampp\htdocs\laravel\resources\views/login.blade.php ENDPATH**/ ?>