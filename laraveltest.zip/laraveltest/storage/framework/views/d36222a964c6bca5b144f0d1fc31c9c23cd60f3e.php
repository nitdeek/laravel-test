<!DOCTYPE html>
<html>
<head>
	<title>
		create order
	</title>
	<style type="text/css">
		*{
			margin:0;
			background-color: black;
		}
		div{
			border: 1px solid black;
			width: 70%;
			margin:auto;
			margin-top: 5%;
		}
		select{
			margin-top: 6%;
			margin-left: 15%;
			margin-right: 5%;
			width: 50%;
			height: 40px;
			font-size: 20px;
			border: 1px solid orange;
			color: orange;
			cursor: pointer;
		}
		h1{
			text-align: center;
			color: white;
			border:0.5px solid orange;
			padding: 1%;
		}
		input{
			color: orange;
			border: 1px solid orange;
			cursor: pointer;
		}
		.sub{
			height: 30px;
			width: 15%;
		}
		a{
			text-decoration: none;
			border:1px solid orange;
			padding: 7px;
			color: white;
		}
		
		
	</style>
</head>
<body>
	<div>
		<?php if(Session::get('status')): ?>
		
		<?php endif; ?>
	<form action="orderplace" method="post">
		<?php echo csrf_field(); ?>
		<h1>Place your order </h1>
		<a href="add">Add product</a>
	<select name="select">
		<option value="0">-select-</option>
		<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($row->id); ?>">
		<?php echo e($row->item_name); ?>

		</option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<input type="submit" name="submit" value="submit" class="sub">
	</select>
	</form>
	</div>

</body>
</html><?php /**PATH D:\xampp\htdocs\laraveltest\resources\views/selectorder.blade.php ENDPATH**/ ?>