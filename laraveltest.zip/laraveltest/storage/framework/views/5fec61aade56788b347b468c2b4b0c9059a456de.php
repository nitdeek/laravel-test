<!DOCTYPE html>
<html>
<head>
	<title></title>
  <meta name="viewport" charset="utf-8" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
<link rel="stylesheet" type="text/css" href="public/css/swiper.min.css">
<link rel="stylesheet" type="text/css" href="public/css/style3.css">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>

<body>
	<section id="nav-bar">
		<nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="laptops"><img src="public/images/nitishlogo.jpg"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item ">
        <a class="nav-link" href="laptops">Home </a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="logout">Log Out</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="#">Contact</a>
      </li>
    </ul>
  </div>
</nav>
</section>

<div class="swiper-container">
    <div class="swiper-wrapper">
      <div class="swiper-slide">
      <div class="imgBx">
        <a target="fm" href="list1"><img src="public/images/laptop14.jpg"></a>
      </div>  
      <div class="details">
        <h3>LENOVO<br><span>ASU34</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <a target="fm" href="list2"><img src="public/images/laptop15.jpg"></a>
      </div>  
      <div class="details">
        <h3>ASUS<br><span>AF67</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <a target="fm" href="list3"><img src="public/images/laptop16.jpg"></a>
      </div>  
      <div class="details">
        <h3>HP<br><span>HP678</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <a target="fm" href="list4"><img src="public/images/laptop17.jpg"></a>
      </div>  
      <div class="details">
        <h3>ACER<br><span>ACG67</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <a target="fm" href="list5"><img src="public/images/laptop18.jpg"></a>
      </div>  
      <div class="details">
        <h3>DELL<br><span>DEh89</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <img src="public/images/laptop3.jpg">
      </div>  
      <div class="details">
        <h3>XIOMI<br><span>MI678</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <img src="public/images/laptop4.jpg">
      </div>  
      <div class="details">
        <h3>HP<br><span>HPh67</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <img src="public/images/laptop5.jpg">
      </div>  
      <div class="details">
        <h3><br>LENOVO<span>LEm90</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <img src="public/images/laptop6.jpg">
      </div>  
      <div class="details">
        <h3>ACER<br><span>ACt34</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <img src="public/images/laptop8.jpg">
      </div>  
      <div class="details">
        <h3>DELL<br><span>DE89</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <img src="public/images/laptop9.jpg">
      </div>  
      <div class="details">
        <h3>APPLE<br><span>Macbook4</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <img src="public/images/laptop10.jpg">
      </div>  
      <div class="details">
        <h3>ACER<br><span>ACh34</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <img src="public/images/laptop11.jpg">
      </div>  
      <div class="details">
        <h3>XIOMI<br><span>MIMAX</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <img src="public/images/laptop12.jpg">
      </div>  
      <div class="details">
        <h3>LENOVO<br><span>LEn67</span></h3>
      </div>
      </div>
      <div class="swiper-slide">
      <div class="imgBx">
        <img src="public/images/laptop13.jpg">
      </div>  
      <div class="details">
        <h3>APPLE<br><span>Macbook5</span></h3>
      </div>
      </div>
    </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>
  <script type="text/javascript" src="public/js/swiper.min.js"></script>
  <script>
    var swiper = new Swiper('.swiper-container', {
      effect: 'coverflow',
      grabCursor: true,
      centeredSlides: true,
      slidesPerView: 'auto',
      coverflowEffect: {

        rotate: 10,
        stretch: -10,
        depth: 90,
        modifier: 5,
        slideShadows : true,
      },
      pagination: {
        el: '.swiper-pagination',
      },
    });
  </script>
      <iframe width="100%" height="400px" src="list6" name="fm"></iframe>

</body>
</html><?php /**PATH D:\xampp\htdocs\laravel\resources\views/login3.blade.php ENDPATH**/ ?>