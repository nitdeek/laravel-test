<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" ></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<style type="text/css">
	.box{
		width:600px;
		margin:0 auto;
		border:1px solid #ccc;
	}
</style>
</head>
<body>
	<div class="container box">
		<?php if(isset(Auth::user()->email)): ?>
		<div class="alert alert-danger success-block">
			<strong>Welcome <?php echo e(Auth::user()->email); ?></strong>
			<br>
			<a href="logout">logout</a>
		</div>
		<?php else: ?>
		<script>window.location="haha";</script>
		<?php endif; ?>
		<br>
	</div>

</body>
</html><?php /**PATH D:\xampp\htdocs\laravel\resources\views/successlogin.blade.php ENDPATH**/ ?>