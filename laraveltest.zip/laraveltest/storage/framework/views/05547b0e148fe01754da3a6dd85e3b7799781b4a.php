<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" ></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<style type="text/css">
	.box{
		width:600px;
		margin:0 auto;
		border:1px solid #ccc;
	}

</style>
</head>
<body>
	<div class="container box">
		<h3 align="center"> login</h3>
		<br>
		<?php if(isset(Auth::user()->email)): ?>
		<script>window.location="successlogin";</script>
		<?php endif; ?>

		<?php if($message = Session::get('error')): ?>
		<div class="alert alert-danger alert-block">
			<button type="button" class="close" data-dismiss="alert">x</button>
			<strong><?php echo e($message); ?></strong>
		</div>
		<?php endif; ?>
		
		<?php if(count($errors)>0): ?>
		<div class="alert alert-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<form method="post" action="<?php echo e(url('checklogin')); ?>">
			<?php echo csrf_field(); ?>
			<div class="form-group">
				<label>enter email</label>
				<input type="email" name="email" class="form-control"/>
			</div>
			<div class="form-group">
				<label>enter password</label>
				<input type="password" name="password" class="form-control" />
			</div>
			<div class="form-group">
				<input type="submit" name="submit" value="login" class="btn btn-primary" />
			</div>
		</form>
	</div>


</body>
</html><?php /**PATH D:\xampp\htdocs\laravel\resources\views/log.blade.php ENDPATH**/ ?>