<?php

namespace App\Http\Middleware;

use Closure;

class go
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $rm=$request->$_POST['remember'];
		if(isset($rm))
		{
			setcookie('ema',$_POST['email'],time()+60);
	setcookie('pas',$_POST['password'],time()+60);
	Redirect()->to('login1')->send();
		}else{
			Redirect()->to('login1')->send();
		}

    }
}
