<?php
session_start();



if(isset($_POST['remember']))
{
	setcookie('ema',$_POST['email'],time()+60);
	setcookie('pas',$_POST['password'],time()+60);
	
}
Redirect()->to('login1')->send();


$_SESSION['emm']=$_POST['email'];
$_SESSION['pss']=$_POST['password'];
?><?php /**PATH D:\xampp\htdocs\laravel\resources\views/login2.blade.php ENDPATH**/ ?>