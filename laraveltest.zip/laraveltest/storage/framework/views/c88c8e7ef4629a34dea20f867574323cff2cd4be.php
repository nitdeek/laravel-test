
<style type="text/css">
	*{
		margin:0;
		background-color: black;
	}
	table{
		border: 1px solid orange;
		color:orange;
		margin:auto;
		margin-top: 7%;
	}
	tr,th,td,caption{
		padding: 25px;
		font-size: 20px;
	}
	input{
		border: 1px solid white;
		color:orange;
		height: 35px;
		width: 100%;
		text-align: center;
		font-size: 15px;
	}
	#ids{
		display:none;
	}
</style>
<form method="post" action="updated" >
	<?php echo csrf_field(); ?>
<table border="1" style="border-collapse: collapse;margin: auto;">
	<caption>update</caption>
	<tr>
		<th>
			item name
		</th>
		<th>
			price
		</th>
		<th>
			description
		</th>
	</tr>
	<tr>
			<input id="ids" type="text" name="id" value="<?php echo e($order->id); ?>">
		<td>
			<input type="text" name="item_name" value="<?php echo e($order->item_name); ?>">
		</td>
		<td>
			<input type="text" name="price" value="<?php echo e($order->price); ?>">
		</td>
		<td>
			<input type="text" name="description" value="<?php echo e($order->description); ?>">
			
		</td>
	</tr>
	<tr>
		<td colspan="4">
		<input style="float: right;cursor: pointer;" type="submit" name="submit" value="submit">
	</td>
	</tr>
</table>
</form><?php /**PATH D:\xampp\htdocs\laravel\resources\views/update.blade.php ENDPATH**/ ?>