<style type="text/css">
	*{
	margin: 0px;
	padding: 0px;
}
body{
	background-image: url(public/img/laptop8.jpg);
	background-size: cover;
	background-attachment: fixed;
}
.container{
	margin:auto;
	margin-top:5%;
	width: 34%;
	box-shadow: -1px 1px 30px 16px black;
	background: rgba(0,0,0,0.6);
}
h3{
	color: white;
	padding:20px;
	text-align: center;
	font-size: 25px;
}
#sub{
	width: 90%;
	margin-left: 5%;
}
input{
	height: 30px;
	width: 97%;
	font-size: 25px;
}
</style>



<div class="container">
<?php if(Session::get('status')): ?>
<p style="color: white;margin-left: 2%;"><b>id already exist rewrite it another.</b></p>
<?php endif; ?>
<h1 style="text-align: center;">CREDENTIALS</h1>
<form method="post" action="add">
	<?php echo csrf_field(); ?>
<table style="width: 100%">
	<tr>
		<td>
			<h3>Id</h3>
		</td>
		<td>
			<input type="text" name="id" >
		</td>
	</tr>
	<tr>
		<td>
			<h3>Enter your name</h3>
		</td>
		<td>
			<input type="text" name="name">
		</td>
	</tr>
		<tr>
		<td colspan="2">
			<input id="sub" type="submit" name="submit" value="submit">
		</td>
	</tr>
</table>
</form>
<?php if ($errors->has('id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('id'); ?>
<p style="color: white;"><b><?php echo e($message); ?></b></p>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
<p style="color: white;"></b><?php echo e($message); ?></b></p>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div><?php /**PATH D:\xampp\htdocs\laraveltest\resources\views/fill.blade.php ENDPATH**/ ?>