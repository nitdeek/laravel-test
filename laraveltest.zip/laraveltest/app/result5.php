<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class result5 extends Model
{
    protected $table="result5";
}
