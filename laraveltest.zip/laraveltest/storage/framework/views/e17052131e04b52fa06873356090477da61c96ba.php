<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>business website</title>
	<link rel="stylesheet" type="text/css" href="public/css/style.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<!--navigation bar-->
	<section id="nav-bar">
		<nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="introduction"><img src="public/images/nitishlogo.jpg"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item ">
        <a class="nav-link" href="#">Home </a>
      </li>
      <li class="nav-item">
      	<a href="logon" class="nav-link">Log In</a>
      </li>
      <li class="nav-item">
      	<a href="register" class="nav-link">Sign Up</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#about">About us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#services">Services</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="#team">Our Team</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="#price">Price Plans</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="#testimonials">Testimonials</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="#contact">Contact</a>
      </li>
    </ul>
  </div>
</nav>
</section>

<div id="slider">
<div id="headerSlider" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#headerSlider" data-slide-to="0" class="active"></li>
    <li data-target="#headerSlider" data-slide-to="1"></li>
    <li data-target="#headerSlider" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="public/images/laptop22.jpeg" class="d-block img-fluid">
      <div class="carousel-caption">
      	<h5 >All Categories</h5>
      </div>
    </div>
    <div class="carousel-item">
      <img src="public/images/laptop9.jpg" class="d-block img-fluid">
      <div class="carousel-caption">
      	<h5 >All Features </h5>
      </div>
    </div>
    <div class="carousel-item">
      <img src="public/images/laptop12.jpg" class="d-block img-fluid">
      <div class="carousel-caption">
      	<h5 >All Prices </h5>
      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#headerSlider" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#headerSlider" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>

<section id="about">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h2>About Us</h2>
				<div class="about-content">
					To start with, let’s look at Wrightwood’s About Us page: a simple, text-centric approach to telling their story. Conveyed in the form of a letter to customers, it uses formatting and font sizes strategically to create variety with text instead of relying on other media types.
What it does best, however, is state its place in the furniture industry against bigger competitors and tell a story about small business experience and passion going up against the status quo that was built by bigger chains.
Plus, it ends off with a thank you from the founders to customers who choose to shop with them.
					</div>
					<button type="button" class="btn btn-primary">Read more>></button>
			</div>
			<div class="col-md-6 skills-bar">
				<p>Perfomance</p>
				<div class="progress">
					<div class="progress-bar" style="width: 99%;">99%</div>
				</div>
				<p>Power</p>
				<div class="progress">
					<div class="progress-bar" style="width: 99%;">99%</div>
				</div>
				<p>Accessability</p>
				<div class="progress">
					<div class="progress-bar" style="width: 99%;">99%</div>
				</div>
				<p>Graphics</p>
				<div class="progress">
					<div class="progress-bar" style="width: 99%;">99%</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section id="services">
	<div class="container">
		<h1>Our Products</h1>
		<div class="row services">
			<div class="col-md-3 text-center">
				<div class="icon">
					<i class="fa fa-laptop"></i>
				</div>
				<h4>Laptops</h4>
				<p>General knowledge is information that has been accumulated over time through various mediums.</p>
			</div>
			<div class="col-md-3 text-center">
				<div class="icon">
					<i class="fa fa-desktop"></i>
				</div>
				<h4>Desktops & AIOs</h4>
				<p>General knowledge is information that has been accumulated over time through various mediums.</p>
			</div>
			<div class="col-md-3 text-center">
				<div class="icon">
					<i class="fa fa-television"></i>
				</div>
				<h4>Computers</h4>
				<p>General knowledge is information that has been accumulated over time through various mediums.</p>
			</div>
			<div class="col-md-3 text-center">
				<div class="icon">
					<i class="fa fa-server"></i>
				</div>
				<h4>Servers</h4>
				<p>General knowledge is information that has been accumulated over time through various mediums.</p>
			</div>
		</div>
	</div>
</section>

<section id="team">
	<div class="container">
		<h1>Our Team</h1>
		<div class="row">
			<div class="col-md-3 profile-pic text-center">
				<div class="img-box">
					<img src="public/images/img2.jpg" class="img-responsive">
					<ul>
						<a href="https://facebook.com"><li><i class="fa fa-facebook"></i></li></a>
							<a href="https://twitter.com"><li><i  class="fa fa-twitter"></i></li></a>
								<a href="https://instagram.com"><li><i class="fa fa-instagram"></i></li></a>
					</ul>
				</div>
				<h2>Nitish Sharma</h2>
				<h3>Founder/CEO</h3>
				<p>To start with, let’s look at Wrightwood’s About Us page: a simple.</p>
			</div>
			<div class="col-md-3 profile-pic text-center">
				<div class="img-box">
					<img src="public/images/img1.jpg" class="img-responsive">
					<ul>
						<a href="https://facebook.com"><li><i class="fa fa-facebook"></i></li></a>
							<a href="https://twitter.com"><li><i  class="fa fa-twitter"></i></li></a>
								<a href="https://instagram.com"><li><i class="fa fa-instagram"></i></li></a>
					</ul>
				</div>
				<h2>Nitish Sharma</h2>
				<h3>Founder/CEO</h3>
				<p>To start with, let’s look at Wrightwood’s About Us page: a simple.</p>
			</div>
			<div class="col-md-3 profile-pic text-center">
				<div class="img-box">
					<img src="public/images/img3.jpg" class="img-responsive">
					<ul>
						<a href="https://facebook.com"><li><i class="fa fa-facebook"></i></li></a>
							<a href="https://twitter.com"><li><i  class="fa fa-twitter"></i></li></a>
								<a href="https://instagram.com"><li><i class="fa fa-instagram"></i></li></a>
					</ul>
				</div>
				<h2>Nitish Sharma</h2>
				<h3>Founder/CEO</h3>
				<p>To start with, let’s look at Wrightwood’s About Us page: a simple.</p>
			</div>
			<div class="col-md-3 profile-pic text-center">
				<div class="img-box">
					<img src="public/images/img5.jpg" class="img-responsive">
					<ul>
						<a href="https://facebook.com"><li><i class="fa fa-facebook"></i></li></a>
							<a href="https://twitter.com"><li><i  class="fa fa-twitter"></i></li></a>
								<a href="https://instagram.com"><li><i class="fa fa-instagram"></i></li></a>
					</ul>
				</div>
				<h2>Nitish Sharma</h2>
				<h3>Founder/CEO</h3>
				<p>To start with, let’s look at Wrightwood’s About Us page: a simple.</p>
			</div>
		</div>
	</div>
</section>

<section id="promo">
	<div class="container">
		<p>Get free accessories with any laptops.</p>
		<a href="register" class="btn btn-primary">Register Now</a>
	</div>
	
</section>

<section id="price">
	<div class="container">
		<h1>Price Plans</h1>
		<div class="row">
			<div class="col-md-3">
				<div class="single-price">
					<div class="price-head">
						<h2>Local</h2>
						<p>$300<span>/Start</span></p>
						</div>
						<div class="price-content">
						<ul>
						<li><i class="fa fa-check-circle"></i>3GB RAM</li>
						<li><i class="fa fa-check-circle"></i>500GB ROM</li>
						<li><i class="fa fa-check-circle"></i>32-Bit</li>
						<li><i class="fa fa-check-circle"></i>i3 Processor</li>
						<li><i class="fa fa-check-circle"></i>14-inch Screen</li>
						</ul>
						</div>
						<div class="price-button">
							<a href="register" class="btn btn-info">Buy Now</a>
						</div>
					
				</div>
			</div>
			<div class="col-md-3">
				<div class="single-price">
					<div class="price-head">
						<h2>Business</h2>
						<p>$400<span>/Start</span></p>
						</div>
						<div class="price-content">
						<ul>
						<li><i class="fa fa-check-circle"></i>4GB RAM</li>
						<li><i class="fa fa-check-circle"></i>1TB ROM</li>
						<li><i class="fa fa-check-circle"></i>64-Bit</li>
						<li><i class="fa fa-check-circle"></i>i3 Processor</li>
						<li><i class="fa fa-check-circle"></i>14-inch Screen</li>
						</ul>
						</div>
						<div class="price-button">
							<a href="register" class="btn btn-info">Buy Now</a>
						</div>
					
				</div>
			</div>
			<div class="col-md-3">
				<div class="single-price">
					<div class="price-head">
						<h2>Gaming</h2>
						<p>$500<span>/Start</span></p>
						</div>
						<div class="price-content">
						<ul>
						<li><i class="fa fa-check-circle"></i>4GB RAM</li>
						<li><i class="fa fa-check-circle"></i>1TB ROM</li>
						<li><i class="fa fa-check-circle"></i>64-Bit</li>
						<li><i class="fa fa-check-circle"></i>i5 Processor</li>
						<li><i class="fa fa-check-circle"></i>15-inch Screen</li>
						</ul>
						</div>
						<div class="price-button">
							<a href="register" class="btn btn-info">Buy Now</a>
						</div>
					
				</div>
			</div>
			<div class="col-md-3">
				<div class="single-price">
					<div class="price-head">
						<h2>Advanced</h2>
						<p>$600<span>/Start</span></p>
						</div>
						<div class="price-content">
						<ul>
						<li><i class="fa fa-check-circle"></i>8GB RAM</li>
						<li><i class="fa fa-check-circle"></i>2TB ROM</li>
						<li><i class="fa fa-check-circle"></i>64-bit</li>
						<li><i class="fa fa-check-circle"></i>i5 Processor</li>
						<li><i class="fa fa-check-circle"></i>15.5-inch Screen</li>
						</ul>
						</div>
						<div class="price-button">
							<a href="register" class="btn btn-info">Buy Now</a>
						</div>
					
				</div>
			</div>
		</div>
	</div>
</section>

<section id="testimonials">
	<div class="container">
		<h1>Testimonials</h1>
		<p class="text-center">Thank you for visiting our Website.</p>
		<div class="row">
			<div class="col-md-4 text-center">
				<div class="profile">
					<img src="public/images/img1.jpg" class="user">
					<blockquote>General knowledge is information that has been accumulated over time through various mediums.General knowledge is information that has been accumulated over time through various mediums.</blockquote>
					<h3>Nitish Sharma <span>Co-Founder of Nitdeek</span></h3>
				</div>
			</div>
			<div class="col-md-4 text-center">
				<div class="profile">
					<img src="public/images/img2.jpg" class="user">
					<blockquote>General knowledge is information that has been accumulated over time through various mediums.General knowledge is information that has been accumulated over time through various mediums.</blockquote>
					<h3>Nitish Sharma <span>Manager of Nitdeek</span></h3>
				</div>
			</div>
			<div class="col-md-4 text-center">
				<div class="profile">
					<img src="public/images/img3.jpg" class="user">
					<blockquote>General knowledge is information that has been accumulated over time through various mediums.General knowledge is information that has been accumulated over time through various mediums.</blockquote>
					<h3>Nitish Sharma <span>Director of Nitdeek</span></h3>
				</div>
			</div>
		</div>
	</div>
</section>

<section id="contact">
	<div class="container">
		<h1 class="text-center">Get In Touch</h1>
		<div class="row">
			<div class="col-md-6">
				<form class="contact-form">
					<div class="form-group">
						<input type="text" name="name" class="form-control" placeholder="Your Name">
					</div>
					<div class="form-group">
						<input type="number" name="phone" class="form-control" placeholder="Phone No">
					</div>
					<div class="form-group">
						<input type="Email" name="email" class="form-control" placeholder="Email Id">
					</div>
					<div class="form-group">
						<textarea class="form-control" name="message" rows="4"
						placeholder="Your Message"></textarea>
					</div>
					<button type="submit" class="btn btn-primary" >Send Message</button>
				</form>
			</div>
			<div class="col-md-6 contact-info">
				<div class="follow"><b>Address:</b><i class="fa fa-map-marker"></i>Xyz Road,Punjab,IN</div>
				
				<div class="follow"><b>Phone:</b><i class="fa fa-phone"></i>1234567898</div>
				
				<div class="follow"><b>Email:</b><i class="fa fa-envelope-o"></i>xyz@gmail.com</div>
				
				<div class="follow"><label><b>Get Social:</b></label>
					<a href="https://facebook.com"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com"><i class="fa fa-twitter"></i></a>
					<a href="https://youtube.com"><i class="fa fa-youtube"></i></a>
					<a href="https://google-plus.com"><i class="fa fa-google-plus"></i></a>
				</div>
				
			</div>
		</div>
	</div>
</section>

<section id="footer">
	<div class="container text-center">
		<p>Thanks for visit<i class="fa fa-heart-o">.</i></p>
	</div>
	
</section>

<script src="public/js/smooth-scroll.js"></script>
<script>
	var scroll = new SmoothScroll('a[href*="#"]');
</script>


</body>
</html>




<?php /**PATH D:\xampp\htdocs\laravel\resources\views/website.blade.php ENDPATH**/ ?>