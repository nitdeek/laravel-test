<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="public/css/style5.css">
	
</head>
<body>
	<section>
		<video src="public/video/smoke.mp4" autoplay muted></video>
		<h1>
			<span>N</span>
			<span>I</span>
			<span>T</span>
			<span>I</span>
			<span>S</span>
			<span>H</span><br>
			
		</h1>

	</section>
	<h2><a href="laptops"><span>Enter</span></a></h2>

</body>
</html><?php /**PATH D:\xampp\htdocs\laravel\resources\views/introduction.blade.php ENDPATH**/ ?>