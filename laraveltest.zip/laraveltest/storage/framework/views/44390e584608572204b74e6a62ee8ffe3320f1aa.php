<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<img height="500px" src="public/images/lap1.jpg">
<img width="890px" src="public/images/lap2.jpg">
</body>
</html><?php /**PATH D:\xampp\htdocs\laravel\resources\views/list6.blade.php ENDPATH**/ ?>