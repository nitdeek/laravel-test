<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<style type="text/css">
	#gayab{
		display: none;
	}
	*{
	margin: 0px;
	padding: 0px;
}
body{
	background-image: url(public/img/laptop8.jpg);
	background-size: cover;
	background-attachment: fixed;
}
.container{
	margin:auto;
	margin-top:5%;
	width: 34%;
	box-shadow: -1px 1px 30px 16px black;
	background: rgba(0,0,0,0.6);
}
h3{
	color: white;
	padding:20px;
	text-align: center;
	font-size: 25px;
}
#sub{
	width: 90%;
	margin-left: 5%;
}
#q1{
	height: 20px;
	width: 57%;
	font-size: 15px;
	float: right;
}
#sub{
	margin-top: 3%;
	margin-bottom: 2%;
	width: 30%;
	font-size: 20px;
}
</style>
<body>
	<div class="container">
<form method="post" action="nextb">
	<?php echo csrf_field(); ?>
	<table style="width: 100%;">
		<tr>
			<td>
			 <label style="font-size: 25px;color: white;" for="q1">Q4:- who is the favorite actor?</label><br>
			</td>
			</tr>
			<tr>
			<td style="color: white;font-size: 22px;">
				salman khan:<input id="q1" type="radio" name="color" value="salman_khan"><br>
				john abrahem:<input id="q1" type="radio" name="color" value="john_abrahem"><br>
				hrithik roshan:<input id="q1" type="radio" name="color" value="hrithik_roshan"><br>
				akshay kumar:<input id="q1" type="radio" name="color" value="akshay_kumar">
				<input id="gayab" type="text" name="testing" value="<?php echo e($testing->id); ?>">
				<input id="gayab" type="text" name="tested" value="<?php echo e($tested->id); ?>">
				<input id="gayab" type="text" name="qid" value="Who is the favorite actor">
				<input id="gayab" type="text" name="qids" value="4">
			</td>
		</tr>
		<tr>
			<td>
				<input id="sub" type="submit" name="submit" value="next">
			</td>
		</tr>
	</table>
</form>
</div>
</body>
</html><?php /**PATH D:\xampp\htdocs\laraveltest\resources\views/answer4.blade.php ENDPATH**/ ?>