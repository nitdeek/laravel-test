<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class result2 extends Model
{
    protected $table="result2";
}
