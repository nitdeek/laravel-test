<style type="text/css">
	body{
		background-color: black;
	}
	#gayab{
		display: none;
	}
	select{
		width: 30%;
		margin-left: 30%;
		margin-top: 7%;
		padding-top: 10px;
		padding-bottom: 10px;
		padding-right: 20px;
		padding-left: 20px;
		font-size: 20px;
		border:3px solid orange;
	}
	input{
		width: 10%;
		height: 40px;
		font-size: 18px;
		margin-left: 2%;
		border:3px solid orange;
	}
</style>
<form method="post" action="goto">
	@csrf
	<input id="gayab" type="text" name="testing" value="{{$testing->id}}" >
	<select name="tested">
		<option>-select-</option>
@foreach($alltested as $ord)

	<option value="{{$ord->id}}">{{$ord->name}}</option>

@endforeach
</select>
<input type="submit" name="submit" value="submit">
</form>