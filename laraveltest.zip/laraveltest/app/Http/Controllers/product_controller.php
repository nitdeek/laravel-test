<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\items;
use App\placed_orders;

class Product_controller extends Controller
{
	//public function __construct(products_model $products_model){
	//	$this->products_model=$products_model;
	//}
	 function view(){
	 	$order=items::all();
    	return view('selectorder',["order"=>$order]);
    }
    function add(Request $req){
    	$item= new items;
    	$item->item_name=$req->input('item_name');
    	$item->price=$req->input('price');
    	$item->description=$req->input('description');
    	$item->save();
    	//$req->session()->flash('status','product submitted successfully');
    	return redirect('selectorder');
    }
    function submit(request $req){
   		$items= new items;
    	$item = $items::find($req->select);
    	$orders= new placed_orders;
    	$orders->item_name=$item->item_name;
    	$orders->price=$item->price;
    	$orders->description=$item->description;
    	$orders->save();
    	$order=placed_orders::all();
    	return view('submittedorder',["order"=>$order]);
    }
    function del(request $req){
    	$placed_order=placed_orders::find($req->id);
    	$placed_order->delete();
    	$order=placed_orders::all();
    	return view('submittedorder',["order"=>$order]);
    }
    function upd(request $req){
    	$order=placed_orders::find($req->id);
    	return view('update',["order"=>$order]);
    }
    function updatd(request $req){
    	placed_orders::where('id',$req->id)->update(['item_name'=>$req->item_name,'price'=>$req->price,'description'=>$req->description]);
    	$order=placed_orders::all();
    	return view('submittedorder',["order"=>$order]);
    }
}


?>