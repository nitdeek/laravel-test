<h1 style="text-align: center;font-size: 40px;color: red;">!Hi {{$testing->name}} your score is!</h1>
<h2 style="text-align: center;font-size: 30px;color: green;">{{$scores}}/5</h2>
<h2 style="text-align: center;">Q1:{{$res1->question}} of {{$tested->name}} ?= {{$res1->answer}}<br> {{$res1->result}}</h2>
<h2 style="text-align: center;">Q2:{{$res2->question}} of {{$tested->name}} ?= {{$res2->answer}} <br>{{$res2->result}}</h2>
<h2 style="text-align: center;">Q3:{{$res3->question}} of {{$tested->name}} ?= {{$res3->answer}} <br>{{$res3->result}}</h2>
<h2 style="text-align: center;">Q4:{{$res4->question}} of {{$tested->name}} ?= {{$res4->answer}} <br>{{$res4->result}}</h2>
<h2 style="text-align: center;">Q5:{{$res5->question}} of {{$tested->name}} ?= {{$res5->answer}} <br>{{$res5->result}}</h2>
<a href="return" style="text-decoration: none;font-size: 30px;color: #00CCCC;margin-left: 45%;">Main Menu</a>