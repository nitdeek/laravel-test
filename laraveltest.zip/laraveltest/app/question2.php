<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class question2 extends Model
{
    protected $table="question2";
}
