<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class fillform extends Model
{
    protected $table="fillform";
}
