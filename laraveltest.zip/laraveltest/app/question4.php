<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class question4 extends Model
{
    protected $table="question4";
}
