<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class results extends Model
{
    protected $table="results";
}
