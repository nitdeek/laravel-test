<style type="text/css">
	body{
		background-color: black;
	}
	#gayab{
		display: none;
	}
	select{
		width: 30%;
		margin-left: 30%;
		margin-top: 7%;
		padding-top: 10px;
		padding-bottom: 10px;
		padding-right: 20px;
		padding-left: 20px;
		font-size: 20px;
		border:3px solid orange;
	}
	input{
		width: 10%;
		height: 40px;
		font-size: 18px;
		margin-left: 2%;
		border:3px solid orange;
	}
</style>
<form method="post" action="goto">
	<?php echo csrf_field(); ?>
	<input id="gayab" type="text" name="testing" value="<?php echo e($testing->id); ?>" >
	<select name="tested">
		<option>-select-</option>
<?php $__currentLoopData = $alltested; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<option value="<?php echo e($ord->id); ?>"><?php echo e($ord->name); ?></option>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<input type="submit" name="submit" value="submit">
</form><?php /**PATH D:\xampp\htdocs\laraveltest\resources\views/viewuser.blade.php ENDPATH**/ ?>