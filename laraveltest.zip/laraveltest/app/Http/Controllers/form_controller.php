<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\fillform;
use App\questions;
use App\users;
use App\results;
use App\question2;
use App\question3;
use App\question4;
use App\question5;
use App\result2;
use App\result3;
use App\result4;
use App\result5;


class form_controller extends Controller
{
    function view(){
    	return view('option');
    }
    function create(){
    	return view('create');
    }
    function choice(Request $req){

    	$data=request()->validate([
    		'id'=>'required',
    		'name'=>'required',
    	]);
    	$person= new fillform;
    	if(fillform::find($req->id)){
    		$req->session()->flash('status','id alreay exist');
    	return view('create');
    	}else{
    	$person->id=$req->input('id');
    	$person->name=$req->input('name');
    	$person->save();
    	$order=fillform::find($req->id);
    	return view('question',["order"=>$order]);

    }
    }
    function nexta(Request $req){
    	if($req->qids==1){
    	$ans=new questions;
    	$ans->id=$req->input('id');
    	$ans->question=$req->input('qid');
    	$ans->answer=$req->input('color');
    	$ans->save();
    	$order=fillform::find($req->id);
    	return view('question2',["order"=>$order]);
    }else if($req->qids==2){
    	$ans=new question2;
    	$ans->id=$req->input('id');
    	$ans->question=$req->input('qid');
    	$ans->answer=$req->input('color');
    	$ans->save();
    	$order=fillform::find($req->id);
    	return view('question3',["order"=>$order]);
    }else if($req->qids==3){
    	$ans=new question3;
    	$ans->id=$req->input('id');
    	$ans->question=$req->input('qid');
    	$ans->answer=$req->input('color');
    	$ans->save();
    	$order=fillform::find($req->id);
    	return view('question4',["order"=>$order]);
    }else if($req->qids==4){
    	$ans=new question4;
    	$ans->id=$req->input('id');
    	$ans->question=$req->input('qid');
    	$ans->answer=$req->input('color');
    	$ans->save();
    	$order=fillform::find($req->id);
    	return view('question5',["order"=>$order]);
    }else if($req->qids==5){
    	$ans=new question5;
    	$ans->id=$req->input('id');
    	$ans->question=$req->input('qid');
    	$ans->answer=$req->input('color');
    	$ans->save();
    	$order=fillform::find($req->id);
    	return view('submitted');
    }

    }
    function fills(Request $req){

    	$data=request()->validate([
    		'id'=>'required',
    		'name'=>'required',
    	]);
    	$person= new users;
    	if(users::find($req->id)){
    		$req->session()->flash('status','id alreay exist');
    	return view('fill');
    	}else{
    	$person->id=$req->input('id');
    	$person->name=$req->input('name');
    	$person->save();
    	$testing=users::find($req->id);
    	$alltested=fillform::all();
    	return view('viewuser',["testing"=>$testing,"alltested"=>$alltested]);

    }
}
function goto(Request $req){
	$testing=users::find($req->testing);
	$tested=fillform::find($req->tested);
	return view('answer1',["tested"=>$tested,"testing"=>$testing]);
}
function nextb(Request $req){
    	if($req->qids==1){
    		$ans=new questions;
    	$anss=$ans::find($req->tested);
    	if($anss->answer==$req->color){
    		$result=new results;
    		$result->id=$req->input('testing');
    		$result->question=$req->input('qid');
    		$result->answer=$req->input('color');
    		$result->score='1';
    		$result->result='true';
    		$result->save();
    		$testing=users::find($req->testing);
	$tested=fillform::find($req->tested);
	return view('answer2',["tested"=>$tested,"testing"=>$testing]);
    	}else if($ans->answer!==$req->color){
    		$result=new results;
    		$result->id=$req->input('testing');
    		$result->question=$req->input('qid');
    		$result->answer=$req->input('color');
    		$result->score='0';
    		$result->result='false';
    		$result->save();
    		$testing=users::find($req->testing);
	$tested=fillform::find($req->tested);
	return view('answer2',["tested"=>$tested,"testing"=>$testing]);
    	}
    }else if($req->qids==2){
    		$ans=new question2;
    	$anss=$ans::find($req->tested);
    	if($anss->answer==$req->color){
    		$result=new result2;
    		$result->id=$req->input('testing');
    		$result->question=$req->input('qid');
    		$result->answer=$req->input('color');
    		$result->score='1';
    		$result->result='true';
    		$result->save();
    		$testing=users::find($req->testing);
	$tested=fillform::find($req->tested);
	return view('answer3',["tested"=>$tested,"testing"=>$testing]);
    	}else if($ans->answer!==$req->color){
    		$result=new result2;
    		$result->id=$req->input('testing');
    		$result->question=$req->input('qid');
    		$result->answer=$req->input('color');
    		$result->score='0';
    		$result->result='false';
    		$result->save();
    		$testing=users::find($req->testing);
	$tested=fillform::find($req->tested);
	return view('answer3',["tested"=>$tested,"testing"=>$testing]);
    	}
    }else if($req->qids==3){
    		$ans=new question3;
    	$anss=$ans::find($req->tested);
    	if($anss->answer==$req->color){
    		$result=new result3;
    		$result->id=$req->input('testing');
    		$result->question=$req->input('qid');
    		$result->answer=$req->input('color');
    		$result->score='1';
    		$result->result='true';
    		$result->save();
    		$testing=users::find($req->testing);
	$tested=fillform::find($req->tested);
	return view('answer4',["tested"=>$tested,"testing"=>$testing]);
    	}else if($ans->answer!==$req->color){
    		$result=new result3;
    		$result->id=$req->input('testing');
    		$result->question=$req->input('qid');
    		$result->answer=$req->input('color');
    		$result->score='0';
    		$result->result='false';
    		$result->save();
    		$testing=users::find($req->testing);
	$tested=fillform::find($req->tested);
	return view('answer4',["tested"=>$tested,"testing"=>$testing]);
    	}
    }else if($req->qids==4){
    		$ans=new question4;
    	$anss=$ans::find($req->tested);
    	if($anss->answer==$req->color){
    		$result=new result4;
    		$result->id=$req->input('testing');
    		$result->question=$req->input('qid');
    		$result->answer=$req->input('color');
    		$result->score='1';
    		$result->result='true';
    		$result->save();
    		$testing=users::find($req->testing);
	$tested=fillform::find($req->tested);
	return view('answer5',["tested"=>$tested,"testing"=>$testing]);
    	}else if($ans->answer!==$req->color){
    		$result=new result4;
    		$result->id=$req->input('testing');
    		$result->question=$req->input('qid');
    		$result->answer=$req->input('color');
    		$result->score='0';
    		$result->result='false';
    		$result->save();
    		$testing=users::find($req->testing);
	$tested=fillform::find($req->tested);
	return view('answer5',["tested"=>$tested,"testing"=>$testing]);
    	}
    }else if($req->qids==5){
    		$ans=new question5;
    	$anss=$ans::find($req->tested);
    	if($anss->answer==$req->color){
    		$result=new result5;
    		$result->id=$req->input('testing');
    		$result->question=$req->input('qid');
    		$result->answer=$req->input('color');
    		$result->score='1';
    		$result->result='true';
    		$result->save();
    		$testing=users::find($req->testing);
    		$res1=results::find($req->testing);
    		$res2=result2::find($req->testing);
    		$res3=result3::find($req->testing);
    		$res4=result4::find($req->testing);
    		$res5=result5::find($req->testing);
    		$scores=$res1->score+$res2->score+$res3->score+$res4->score+$res5->score;
	$tested=fillform::find($req->tested);
	return view('result',["tested"=>$tested,"testing"=>$testing,"scores"=>$scores,"res1"=>$res1,"res2"=>$res2,"res3"=>$res3,"res4"=>$res4,"res5"=>$res5]);
    	}else if($ans->answer!==$req->color){
    		$result=new result5;
    		$result->id=$req->input('testing');
    		$result->question=$req->input('qid');
    		$result->answer=$req->input('color');
    		$result->score='0';
    		$result->result='false';
    		$result->save();
    		$testing=users::find($req->testing);
    		$res1=results::find($req->testing);
    		$res2=result2::find($req->testing);
    		$res3=result3::find($req->testing);
    		$res4=result4::find($req->testing);
    		$res5=result5::find($req->testing);
    		$scores=$res1->score+$res2->score+$res3->score+$res4->score+$res5->score;
	$tested=fillform::find($req->tested);
	return view('result',["tested"=>$tested,"testing"=>$testing,"scores"=>$scores,"res1"=>$res1,"res2"=>$res2,"res3"=>$res3,"res4"=>$res4,"res5"=>$res5]);
    	}
    } 






    }

}