<h1 style="text-align: center;font-size: 40px;color: red;">!Hi <?php echo e($testing->name); ?> your score is!</h1>
<h2 style="text-align: center;font-size: 30px;color: green;"><?php echo e($scores); ?>/5</h2>
<h2 style="text-align: center;">Q1:<?php echo e($res1->question); ?> of <?php echo e($tested->name); ?> ?= <?php echo e($res1->answer); ?><br> <?php echo e($res1->result); ?></h2>
<h2 style="text-align: center;">Q2:<?php echo e($res2->question); ?> of <?php echo e($tested->name); ?> ?= <?php echo e($res2->answer); ?> <br><?php echo e($res2->result); ?></h2>
<h2 style="text-align: center;">Q3:<?php echo e($res3->question); ?> of <?php echo e($tested->name); ?> ?= <?php echo e($res3->answer); ?> <br><?php echo e($res3->result); ?></h2>
<h2 style="text-align: center;">Q4:<?php echo e($res4->question); ?> of <?php echo e($tested->name); ?> ?= <?php echo e($res4->answer); ?> <br><?php echo e($res4->result); ?></h2>
<h2 style="text-align: center;">Q5:<?php echo e($res5->question); ?> of <?php echo e($tested->name); ?> ?= <?php echo e($res5->answer); ?> <br><?php echo e($res5->result); ?></h2>
<a href="return" style="text-decoration: none;font-size: 30px;color: #00CCCC;margin-left: 45%;">Main Menu</a><?php /**PATH D:\xampp\htdocs\laraveltest\resources\views/result.blade.php ENDPATH**/ ?>